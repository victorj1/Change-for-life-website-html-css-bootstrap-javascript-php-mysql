<?php

$server = "localhost:3306";
$user = "changft8_login";
$password = "Stanmore_97";
$dbname = "changft8_cflblog";

$conn = mysqli_connect($server,$user,$password,$dbname);

if(!$conn){
	die("Connection Failed".mysqli_connect_error());
}
else{
	
}
?>